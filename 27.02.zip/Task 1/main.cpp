#include <iostream>
#include "task1.h"

using namespace std;

int main()
{
    cout << global_value << endl;
}