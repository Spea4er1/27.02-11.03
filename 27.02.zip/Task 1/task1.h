//
// Created by samuraj on 25.02.23.
//

#ifndef MULTIFILE_HW_TASK1_HEADER_H
#define MULTIFILE_HW_TASK1_HEADER_H

#endif //MULTIFILE_HW_TASK1_HEADER_H

extern int global_value;
