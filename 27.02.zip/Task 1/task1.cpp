//
// Created by samuraj on 25.02.23.
//
int global_value = 6;
