#include <iostream>


std::pair<int, int> Swap(int a, int b)
{
    return std::pair<int, int>(b, a);
}
