static int n;
//void Display(int n);