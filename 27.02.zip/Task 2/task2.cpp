#include <iostream>
#include "task2_header.h"

using namespace std;

int Display(int a)
{
	cout << a << endl;
}

int main()
{
	n = 33;
	Display(n);
}